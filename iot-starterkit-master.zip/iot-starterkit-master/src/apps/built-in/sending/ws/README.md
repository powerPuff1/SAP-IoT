# Sending messages from the device

## Send messages with MMS built-in sample client using WebSocket API

* Click on "HTTP API" tile

![MMS Send Built-in WS](../../../../../images/mms_send_builtin_ws_01.png)

1. Adapt the Device ID if required
2. Adapt the Message if required
3. Click on Post button

![MMS Send Built-in WS](../../../../../images/mms_send_builtin_ws_02.png)
