# Receiving the messages sent to the device

## Receive the messages with MMS built-in client

* Click on "Application Data" tile

![MMS Fetch Built-in](../../../../images/mms_consume_builtin_01.png)

* Select the "T_IOT_HTTP_PUSH" table to see the messages sent to the device

![MMS Fetch Built-in](../../../../images/mms_consume_builtin_03.png)

![MMS Fetch Built-in](../../../../images/mms_consume_builtin_03a.png)