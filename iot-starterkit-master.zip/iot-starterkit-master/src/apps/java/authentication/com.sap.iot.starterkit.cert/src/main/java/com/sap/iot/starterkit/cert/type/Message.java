package com.sap.iot.starterkit.cert.type;

public class Message {

}
