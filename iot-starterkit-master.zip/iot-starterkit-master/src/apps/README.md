This directory holds specific applications that can be used with the SAP Cloud Platform Internet of Things.
