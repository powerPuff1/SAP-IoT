This directory holds specific examples that integrate "code snippets" into
programs with working end-to-end functionality.
