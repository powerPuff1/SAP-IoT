These code snippets show primitives for interacting with the SAP Cloud Platform Internet of Things via https as well as their usage to transfer the content of a file.

Note that the java files are not provided as a java project, instead they 
have to be copied into a java project.
